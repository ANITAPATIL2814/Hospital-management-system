package com.demo.exception;

public class LabTestNotFoundException extends Exception  {

	private static final long serialVersionUID = 1L;

	public LabTestNotFoundException(String message ) {
		super(message);
	}
	
}
